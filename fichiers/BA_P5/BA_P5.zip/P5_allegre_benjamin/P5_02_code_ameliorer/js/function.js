// JavaScript source code

/**
* getRandomNumber - return a number between 0 and max
* @param max {number} the maximum number
* @returns number the generated number
*/
function getRandomNumber(max) {
    let number = Math.floor(Math.random() * max);
    return number;
}