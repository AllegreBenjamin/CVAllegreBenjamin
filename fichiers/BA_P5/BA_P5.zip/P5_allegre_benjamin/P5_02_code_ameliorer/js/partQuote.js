/**
 * constant - table contain the different starting part of the quote
 * @type {Array}
 * */
const quotePartStart = [
    ' Avec',
    ' Consid�rant',
    ' O� que nous m�ne',
    ' Vu',
    ' En ce qui concerne'
];
/**
 * constant - table contain the different middle part of the quote
 * @type {Array}
 * */
const quotePartMiddle = [
    'la crise',
    'l\'inertie',
    'la difficult�',
    'l\'aust�rit�',
    'la d�gradation'
];
/**
 * constant - table contain the different middle2 part of the quote
 * @type {Array}
 * */
const quotePartMiddle2 = [
    'pr�sente',
    'actuelle',
    'g�n�rale',
    'induite',
    'conjoncturelle'
];
/**
 * constant - table contain the different middle3 part of the quote
 * @type {Array}
 * */
const quotePartMiddle3 = [
    '� court terme',
    'rapidement',
    'dans une perspective correcte',
    'avec toute la prudence requise',
    'de toute urgence'
];
/**
 * constant - table contain the different end part of the quote
 * @type {Array}
 * */
const quotePartEnd = [
    'imaginables',
    'possibles',
    's\'offrant � nous',
    'de bon sens',
    'envisageables'
];
