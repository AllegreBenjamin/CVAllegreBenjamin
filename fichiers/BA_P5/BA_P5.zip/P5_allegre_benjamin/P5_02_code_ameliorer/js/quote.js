// JavaScript source code
/**
 * getRandomQuote - returns an array with getRandomNumber (5)
 * @param array {array} table contain the different pieces of sentence.
 * @returns {any} 
 */
function getRandomQuote(array) {
    return array[getRandomNumber(5)];
}

/**
 * generateQuote - generate the quote (s) based on the typeQuote and numQuote
 * @param numQuote {number} number of quotes that we want to generate
 * @param typeQuote {number} type of quote that we want to generate
 * @returns array
 */
function generateQuote(numQuote, typeQuote) {
    const tab = [];
    for (let i = 0; i < numQuote; i++) {
        if (typeQuote == 1) {
            let quotePartStartRandom = getRandomQuote(quotePartStart);
            let quotePartMiddleRandom = getRandomQuote(quotePartMiddle);
            let quotePartEndRandom = getRandomQuote(quotePartEnd);
            const quote = new Quote(quotePartStartRandom, quotePartMiddleRandom, quotePartEndRandom);
            tab[i] = quote;
        } else {
            let quotePartStartRandom = getRandomQuote(quotePartStart);
            let quotePartMiddleRandom = getRandomQuote(quotePartMiddle);
            let quotePartMiddle2Random = getRandomQuote(quotePartMiddle2);
            let quotePartMiddle3Random = getRandomQuote(quotePartMiddle3);
            let quotePartEndRandom = getRandomQuote(quotePartEnd);
            const quote = new Quote(quotePartStartRandom, quotePartMiddleRandom, quotePartMiddle2Random, quotePartMiddle3Random, quotePartEndRandom);
            tab[i] = quote;
        }
    }
    return tab;
}
/**
 * choice variable allow if 1 continue or 0 exit the program.
 * @type {number}
 */
let choice = 1;

/**
 * retrieval via DOM querySelector element form
 * @type {HTMLFormElement}
 */
let form = document.querySelector("form");


form.addEventListener("submit", function (e) {
    e.preventDefault();
    /**
     * number of quotes that we want to generate
     * @type {number}
     */
    let numQuote = form.elements.numberQuote.value;
    /**
     * type of quote that we want to generate
     * @type {number}
     */
    let typeQuote = form.elements.typeQuote.value;

    while (choice !== 0) {
        /** 
         *  constant - receive them or quote generate
         *  @type {object}
         */
        const tabQuote = generateQuote(numQuote, typeQuote);

        for (let i = 0; i < numQuote; i++) {
            /**
             * constant - receives each party from the quotes
             * @type {string}
             */
            const quote = tabQuote[i];
            console.log("Voici la citation :" + quote.toDescribe());

        }
        choice = Number(prompt("Voulez vous continuer 1 pour oui 0 pour quitter."));
        break;
    }
    
    
});


