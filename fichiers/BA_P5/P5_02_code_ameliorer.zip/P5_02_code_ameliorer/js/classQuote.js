
/**
 * Create a Quote.
 * @class
 * */
class Quote {
    /**
     * @constructor
     * @param quotePartStartRandom {string} quote Party Start Random
     * @param quotePartMiddleRandom {string} quote Party Middle Random
     * @param quotePartEndRandom {string} quote Party End Random
     * @param quotePartMiddle2Random {string} quote Party Middle2 Random
     * @param quotePartMiddle3Random {string} quote Party Middle3 Random
     */
    constructor(quotePartStartRandom, quotePartMiddleRandom, quotePartEndRandom, quotePartMiddle2Random, quotePartMiddle3Random) {
        this.quotePartStart = quotePartStartRandom;
        this.quotePartMiddle = quotePartMiddleRandom;
        this.quotePartEnd = quotePartEndRandom;
        if (quotePartMiddle2Random && quotePartMiddle3Random) {
            this.quotePartMiddle2 = quotePartMiddle2Random;
            this.quotePartMiddle3 = quotePartMiddle3Random;
        }
    }

   
    toDescribe() {
        if (this.quotePartMiddle2 && this.quotePartMiddle3) {
            return (this.quotePartStart + " " + this.quotePartMiddle + " " + this.quotePartMiddle2 + " " + this.quotePartMiddle3 + " " + this.quotePartEnd + ".");
        } else {
            return (this.quotePartStart + " " + this.quotePartMiddle + " " + this.quotePartEnd + ".");
        }
    }

};