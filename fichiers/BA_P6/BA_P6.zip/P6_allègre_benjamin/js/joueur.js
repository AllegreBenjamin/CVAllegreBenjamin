/**
 * Create a Player.
 * @class
 * */
class Joueur {
    /**
     * @constructor
     * @param id {number} id player id - identifiant du joueur
     * @param nom {string} nom name player - nom du joueur
     * @param arme {object} arme(1) Call from the weapon class initialized to 1 by default. - Appel depuis class arme initialis� � 1 par d�faut.
     * @param design {string} design arme.getDesignArmeJoueur() 
     * @param posture {boolean} posture default posture -> false for defense if not true for attack - posture par d�faut -> faux pour la d�fense sinon vrai pour l'attaque
     * @param pv {number} pv initialized to 100 are the hit points - initialis�s � 100 sont les points de vie
     * @param position {number} position contains the position of the player - contient la position du joueur
     * @param ancienne_arme {number} ancienne_arme used when picking up a weapon, to return it to the original location - utilis� pour ramasser une arme, pour la ramener � son emplacement d'origine
     */
    constructor(id, nom) {
        this.nom = nom;
        this.id = id;
        this.arme = new Arme(1);
        this.design = this.arme.getDesignArmeJoueur();
        this.posture = false;
        this.pv = 100;
        this.position = [-1, -1];
        this.ancienne_arme = -1;

    }
    /**
     * @updateArme - update of the weapon id as well as the design - mise � jour de l'identifiant de l'arme ainsi que du design
     * @param id_arme {number} id_arme weapon_id allows updating - arme_id permet la mise � jour
     */
    updateArme(id_arme) {

        this.ancienne_arme = this.arme.id; // Here we put the level of the old weapon - Ici on met le niveau de l'ancienne arme
        this.arme = new Arme(id_arme); // We update the weapon object - Nous mettons � jour l'objet arme
        this.design = this.arme.getDesignArmeJoueur(); // We update the design of the weapon - Nous mettons � jour l'objet arme

    }
    /**
     * @updatePosture - posture update via boolean (defense or attack) - mise � jour de la posture via bool�en (d�fense ou attaque)
     * @param bool_posture {boolean} bool_posture
     */
    updatePosture(bool_posture) {

        this.posture = bool_posture;

    }

    /**
     * @recevoirDegats - function allow you to manage damage - la fonction vous permet de g�rer les dommages
     * @param arme_ennemi {number} arme_ennemi lets you know the damage that the player receives - vous permet de conna�tre les d�g�ts que le joueur subit
     */
    recevoirDegats(arme_ennemi) {
        var degats = arme_ennemi.degats;
        if(!this.posture) {

            degats = Math.round(degats/2);

        }
        if(this.pv < degats) 
            this.pv = 0;
         else 
            this.pv -= degats;
    }

}