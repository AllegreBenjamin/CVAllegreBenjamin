/**
 * Create a Weapon - Créer une arme
 * @class
 * */
class Arme {
    /**
     * @constructor
     * @param id {number} id weapon number (possibly 1,2,3,4). - numéro d'identification de l'arme (éventuellement 1,2,3,4).
     * @param position {number} position weapon position (default). - position de l'arme (par défaut).
     */
    constructor(id, position) {

        this.id = id;
        this.position = position;
        
        switch(this.id) {

            case 1: // Standard weapon - arme standard
                this.degats = 10;
                this.nom = "Couteau";
            break;
            case 2:
                this.degats = 15;
                this.nom = "Épée";
            break;
            case 3:
                this.degats = 20;
                this.nom = "Hache";
            break;
            case 4:
                this.degats = 25;
                this.nom = "Excalibur";
            break;

        }
    }
/**
 * @getDesignArmeJoueur get the path to the image of the player carrying the weapon he just picked up - obtenir le chemin vers l'image du joueur portant l'arme qu'il vient de ramasser
 * @return {string} Path to player image - chemin de l'image joueur
 */
    getDesignArmeJoueur() {

        return "img/j_arme"+ String(this.id)+ ".png";

    }
    
}
