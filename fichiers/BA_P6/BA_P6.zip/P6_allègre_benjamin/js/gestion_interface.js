/**
 * Create a Interface
 * @class
 * */
class Interface {
    /**
     * @constructor
     * @param joueur1 {object} joueur1 player object created line 25 in main.js - objet joueur créé à la ligne 25 dans main.js
     * @param joueur2 {object} joueur2 player object created line 26 in main.js - objet joueur créé à la ligne 26 dans main.js
     */
    constructor(joueur1, joueur2) {

        $("#interface").css("display", "inline");
        $("#nom_j1").html(joueur1.nom);
        $("#nom_j2").html(joueur2.nom);

    }
    /**
     * @genInterfaceCombat - Displays attack and defense buttons - Affiche les boutons attaque et défense
     * @param joueur_actuel {object} joueur_actuel contains the player object - contient l'objet joueur
     */
    genInterfaceCombat(joueur_actuel) {  

        var $div_combat = $("<div class='col-12 d-flex justify-content-around'></div>"),

            $btn_attaque = $("<button class='float-left' id='btn_attaque'>Attaquer</button>"),

            $btn_defense = $("<button class='float-right' id='btn_defense'>Défendre</button>"),

            id_joueur = joueur_actuel.id;

        $div_combat.attr("id", "boutons_combat");
        $div_combat.css("display", "none");

        $div_combat.append($btn_attaque);

        $div_combat.append($btn_defense);

        $("#interface_" + String(id_joueur)).append($div_combat);

        $div_combat.slideDown(200);

    }
    /**
     * @updateInterfaceCombat - Updates the health bar and the HP text, we send the enemy's ID to easily find the data - Met à jour la barre de vie et le texte des PV, on envoie l'id de l'ennemi pour facilement retrouver les données
     * @param ennemi {object} ennemi contains the player object - contient l'objet joueur
     * @param _callback {any} _callback function passed into another function as an argument, which is then invoked inside the outer function to accomplish some sort of routine or action. - fonction passée dans une autre fonction en tant qu'argument, qui est ensuite appelée à l'intérieur de la fonction externe pour accomplir une sorte de routine ou d'action.
     */
    updateInterfaceCombat(ennemi, _callback) { 

        $("#barre_j" + String(ennemi.id)).animate({
            "value": ennemi.pv
        }, 800, "swing", function() {

            _callback();

        });

        $("#vie_j" + String(ennemi.id)).html(String(ennemi.pv) + " / 100 PV");

    }
    /**
     * @updateArme - Function updating the name, image and damage of the weapon in the interface - Fonction de mise à jour du nom, de l'image et des dégâts de l'arme dans l'interface
     * @param joueur {object} joueur contains the player object - contient l'objet joueur
     * @param arme {any} arme contains the weapon object - contien l'objet arme
     */
    updateArme(joueur, arme) { 

        $(`#nom_arme_j${joueur.id}`).html(joueur.arme.nom);
        $(`#degats_arme_j${joueur.id}`).html(joueur.arme.degats);
        $(`.joueur${joueur.id}`).attr("src", joueur.design);
        $(`.interface-joueur${joueur.id}`).attr("src", joueur.design);

    }

}
