/* Joueur, Interface, Grille, globals $ */

$(document).ready(function() {

    
    $("h1").css("display", "block"); // To prevent the title from being displayed before loading the grid & interface - Pour éviter que le titre soit affiché avant de charger la grille & l'interface
    // player name entry request - demande de saisis de nom des joueurs
    var nom_j1 = prompt("Entrez le nom du joueur 1 : "),

        nom_j2 = prompt("Entrez le nom du joueur 2 : ");

    // if the player has not entered a name - si le joueur n'a pas entré de nom
    if (!nom_j1) {

        nom_j1 = "Joueur 1";

    }

    if (!nom_j2) {

        nom_j2 = "Joueur 2";

    }

 
    /**
     * @var joueur1 New Object Joueur joueur1 - Nouvel objet Joueur joueur1
     * @var joueur2 New Object Joueur joueur2 - Nouvel objet Joueur joueur2
     * @var joueur_actuel default undefined - par defaut undefined
     * @var combat boolean
     * @var grille New Object Grille(joueur1, joueur2) - Nouvel objet Grille(joueur1, joueur2)
     * @var interface_jeu New Object Interface(joueur1, joueur2) - Nouvel objet Interface(joueur1, joueur2)
     * @var nb_tours type numerique initialisé a 0 - numeric type initialized to 0
     */
    var joueur1 = new Joueur(1, nom_j1),
        joueur2 = new Joueur(2, nom_j2),
        joueur_actuel,
        combat = false,
        grille = new Grille(joueur1, joueur2),
        interface_jeu = new Interface(joueur1, joueur2),
        nb_tours = 0; 

  

    // We display the whole page at the same time - On affiche toute la page en même temps
    $("body").fadeIn(500);

    resizeGrid();

    $(window).resize(resizeGrid);

    // Beginning of the game - Commencement du jeu

    gestionTour();
    /**
     * @resezeGrid responsive management - gestion responsive
     */
    function resizeGrid() {

        if ($(document).width() < 580) {
            var $width = $("table").width(), // Game board width - Largeur du tableau de jeu
                $td_width = Math.trunc($width / 10), // We get the closest value below (0.6px wouldn't make sense) - On récupère la valeur la plus proche en-dessous (0.6px n'auraient aucun sens)
                $final_width = $td_width * 10; // We recalculate the final size of the array - On recalcule la taille finale du tableau

            $("table").css({
                "height": `${$final_width}px`,
                "width": `${$final_width}px`
            });
            $("td").css({
                "height": `${$td_width}px`,
                "width": `${$td_width}px`
            });
        }
    }
    /**
     * @deplacerJoueur Function that allows the player to move by click - fonction qui permet au joueur de se déplacer par clic 
     * @param e {*} e jQuery.Event type click
     */
    function deplacerJoueur(e) {
        
        $(".dep_possible").off("click", deplacerJoueur);

        var position = e.target.id.split("-"),
            anc_position = joueur_actuel.position;
           
        if (position.length !== 2) { // If we click on the image of a weapon, we search for the parent id - Si l'on clique sur l'image d'une arme, on recherche l'id du parent

            position = $(e.target).parent().attr("id").split("-");

        }

        var arme = grille.updatePosition(joueur_actuel, position); // We update the player's position on the back grid - On remet à jour la position du joueur sur la grille back

        if (arme !== -1) { // If the player comes across a new weapon - Si le joueur tombe sur une nouvelle arme

            joueur_actuel.updateArme(arme);

            interface_jeu.updateArme(joueur_actuel);

        }

        grille.updateGrilleEcran(joueur_actuel, anc_position, position, arme); // We update the front grille - On remet à jour la grille front

        gestionTour();

    }
    /**
     * @gestionTour Allows the management of player turns in combat, movement display possible - Permet la gestion des tours joueurs en combat, affichage déplacement possible
     */
    function gestionTour() {

        joueur_actuel = grille.joueurs[nb_tours % 2];
        
        if (!combat) { // Stage 1 of the game - Étape 1 du jeu

            if (grille.estEnCombat()) {

                combat = true;

                gestionTour(); // We recall the function to switch to combat === true - On rappelle la fonction pour passer dans combat === true

            } else {

                var position = joueur_actuel.position;

                // We display the possible movements of the player - On affiche les déplacements possibles du joueur

                grille.afficherDepDispos(position, deplacerJoueur);

                nb_tours += 1;

            }

        } else {

            if (joueur_actuel.pv === 0) { // We check if the current player still has pv - On vérifie si le joueur actuel a encore des PV

                var vainqueur = grille.joueurs[(nb_tours + 1) % 2];

                alert(`${vainqueur.nom} a gagné !`);

            } else { // If he has any, we continue the fight - S'il en a, on continue le combat

                interface_jeu.genInterfaceCombat(joueur_actuel);

                $("#btn_attaque").on("click", gestionCombat);
                $("#btn_defense").on("click", gestionCombat);

            }

        }

    }
    /**
     * @gertionCombat Management callback function Turn in case of combat - Fontion callback de gestionTour en cas de combat
     * @param e {*} e jQuery.Event type "click"
     */
    function gestionCombat(e) {
       
        $("button").off("click", gestionCombat);

        $("#boutons_combat").remove();

        nb_tours += 1;

        var decision = e.target.id.replace("btn_", "");

        if (decision === "defense") {

            joueur_actuel.updatePosture(false);

            gestionTour();

        } else {

            var ennemi = (joueur_actuel === joueur1) ? joueur2 : joueur1;

            ennemi.recevoirDegats(joueur_actuel.arme);

            joueur_actuel.updatePosture(true); // Since he attacked, we pass the posture of the player in attack - Puisqu'il a attaqué, on passe la posture du joueur en offensif

            interface_jeu.updateInterfaceCombat(ennemi, gestionTour);

        }

    }

});
