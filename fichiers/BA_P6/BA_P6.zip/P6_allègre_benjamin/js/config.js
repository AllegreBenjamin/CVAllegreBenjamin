
/**
 * @constant
 * @type NB_X {number} constant pour definir l'axe x de la grille
 * @type NB_Y {number} constant pour definir l'axe y de la grille par l'axe x
 * @type NB_ARME {number} constant pour definir le nombre d'arme
 * @type NB_CASE_GRISEE {number} constant pour definir le nombre de case gris�ez
 * */
const NB_Y = 11,
    NB_X = NB_Y,
    NB_ARME = 3,
    NB_CASE_GRISEE = 13;